// config.ts — the one place your backend address lives.
export const API_URL: string = "http://10.16.240.166:8080";